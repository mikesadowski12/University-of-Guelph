#NAME: Mike Sadowski
#DATE: October 14th, 2014
#STUDENT ID: 0864810
#ASSIGNEMNT: Data Structures Assignment 2

======Important Notes:============
- if any of the text files have an extra space in any line, the program will not load them correctly

======Compilation/Running:==============
1: locate directory with all required files (q1.c carStructure.c carStruct.h q2.c available.txt rented.txt repair.txt makefile) in terminal
2: type 'make' 
3: typing in './a2_1' - runs question 1, loading all pre-made cars from the text files provided
             './a2_2 <postfix expression>' - runs question 2, provides result of the postfix expression provided

======Sample Output:============ 
--q1.c:
1.Add a new car to the available-for-rent list
2.Add a returned car to the available-for-rent list
3.Add a returned car to the repair list
4.Transfer a car from the repair list to the available-for-Rent list
5.Rent first avaiable car
6.Print all the lists
7.Quit
>>>>Choice: 1
Please enter the mileage: 100
Please enter the plate-number: ffff

>>>New car has been added to the available list!


--q2.c:
Expression: 99+
Answer: 18.00

======Sources:============
www.cs.colb.edu/maxwell/courses/tutorials/maketutor/
The Textbook
Slides from moodle (course website) for stack functions
stackoverflow.com/questions/628761/character-to-integer-in-c 



