NOTES:

-AI moves just how its supposed to, but the large animations did not fit in the maze
so I just made them with mobs
-animations I made are outside of the maze (look at the map to find them)
-AI does shoot, but they are on a timer. it is very inconsistent between the fire times but they do shoot at you if you wait (did this because the rate of fire was so high before)
-when the eyes look at you, it is in ‘dodge’ mode and will run around aimlessly to be harder to hit