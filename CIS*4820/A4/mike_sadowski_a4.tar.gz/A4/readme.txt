NOTES:

-AI moves just how its supposed to, but the large animations did not fit in the maze
so I just made them with mobs
-animations I made are outside of the maze (look at the map to find them)
-AI does shoot, but they are on a timer. it is very inconsistent between the fire times but they do shoot at you if you wait (did this because the rate of fire was so high before)
-when the eyes look at you, it is in ‘dodge’ mode and will run around aimlessly to be harder to hit
-sometimes it looks like they go through a wall, but they don’t, its only a graphic glitch. if they get stuck in a wall the teleport out by 1 block down in the X direction



-red is teleport
-green is bounce
-yellow cube is now the rain (instead of blue)
-3 hits and you die, once your health goes down maze re-initializes
-bringing the key to the door re-initializes maze as well
-everything but the door is placed in a random location every time (2 of each power up)